#include "pirate/unz_pirate.h"

namespace pirate {

unz_pirate::unz_pirate(const std::string& zip_path) {}

unz_pirate::~unz_pirate() {}

int unz_pirate::init() {
  if (handle_) {
    handle_ = unzOpen64(zip_path_.data());
  }

  return handle_ ? 0 : -1;
}

void unz_pirate::deinit() {
  if (handle_) {
    unzClose(handle_);
  }
}

}  // namespace pirate
